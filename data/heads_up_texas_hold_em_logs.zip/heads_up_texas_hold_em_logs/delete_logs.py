#!/usr/bin/env python3
"""
merge_logs.py  –  pair mirror‑image single‑hand logs

• Looks for heads_up_holdem_*.log (skips existing *_pair_*.log).
• When two logs have the same two models and the same two hole‑card
  combinations (ignoring order), they become a “paired round”:
    ─ creates heads_up_holdem_pair_<ts>-<rand>.log
• Metadata for every pair is collected into one big
  heads_up_holdem_pairs.json (array of objects).
• Any log left unpaired after the scan is deleted.

Run in the directory that contains the logs:

    python3 merge_logs.py
"""

import json, pathlib, random, re, sys, time

LOG_RE   = re.compile(r"heads_up_holdem_(\d{8}-\d{6})-\d{6}\.log$")
PAIR_RE  = re.compile(r"heads_up_holdem_pair_")
MODEL_RE = re.compile(r"\(([^)]+)\)")
HOLE_RE  = re.compile(r"P[01] hole:\s+([^\n/]+)/?\s+stack")

def parse_log(path: pathlib.Path):
    txt = path.read_text(errors="ignore")

    ts = LOG_RE.search(path.name)[1]
    models = MODEL_RE.findall(txt)[:2]
    holes  = HOLE_RE.findall(txt)[:2]

    key_models = frozenset(models)
    key_holes  = frozenset(sorted(holes))

    win_line = next(ln for ln in txt.splitlines() if "WINS the pot" in ln)
    winner   = MODEL_RE.search(win_line)[1]
    chips    = int(re.search(r"Net\s+\+?(-?\d+)", win_line)[1])

    losers   = [m for m in key_models if m != winner] or list(key_models)
    meta = {
        "timestamp": ts,
        "winner":    winner,
        "losers":    losers,
        "round_log_file": path.name,
        "chips_won": chips
    }
    return (key_models, key_holes), meta, txt

def main() -> None:
    here = pathlib.Path(".")
    pending: dict[tuple[frozenset, frozenset], tuple[dict, str, pathlib.Path]] = {}
    pairs_meta: list[dict] = []
    paired_ct = 0

    for log in sorted(here.glob("heads_up_holdem_*.log")):
        if PAIR_RE.match(log.name):
            continue
        try:
            key, meta, raw = parse_log(log)
        except Exception as e:
            print(f"⚠️  {log.name}: {e}", file=sys.stderr)
            continue

        if key in pending:
            first_meta, first_raw, first_path = pending.pop(key)
            subs = sorted([first_meta, meta], key=lambda d: d["timestamp"])
            ts_out = subs[-1]["timestamp"]
            rand   = random.randint(100000, 999999)
            base   = f"heads_up_holdem_pair_{ts_out}-{rand:06d}"
            log_out = here / f"{base}.log"

            log_out.write_text(
                first_raw.rstrip() +
                "\n--- Paired hand restart (models swapped) ---\n" +
                raw.lstrip()
            )

            pairs_meta.append({
                "timestamp": ts_out,
                "sub_hands": subs,
                "round_log_file": log_out.name
            })
            paired_ct += 1
            print(f"✅ paired → {log_out.name}")

            # keep originals; only unpaired singles are destroyed later
        else:
            pending[key] = (meta, raw, log)

    # dump the giant JSON file (overwrite each run)
    json_path = here / "heads_up_holdem_pairs.json"
    json_path.write_text(json.dumps(pairs_meta, indent=2))
    print(f"\n📝 wrote {json_path.name} with {paired_ct} entries.")

    # nuke orphans
    for _, (_, __, orphan_path) in pending.items():
        try:
            orphan_path.unlink()
            print(f"🗑️  deleted orphan {orphan_path.name}")
        except Exception as e:
            print(f"⚠️  couldn’t delete {orphan_path.name}: {e}", file=sys.stderr)

    print(f"\nDone. {paired_ct} pairs written, {len(pending)} orphans removed.")

if __name__ == "__main__":
    main()
